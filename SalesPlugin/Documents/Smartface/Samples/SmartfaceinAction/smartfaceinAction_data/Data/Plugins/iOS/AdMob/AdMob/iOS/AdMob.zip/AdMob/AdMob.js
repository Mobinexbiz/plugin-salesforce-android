var f = require('util').format;
var requirements = {
    fs: require('fs'), //for file system operations
    path: require('path') //for setting correct path based on OS
};

var exec = require('child_process').exec;
var shouldLog = false;

forceRequire(requirements, ['xcode' //for modifieing Xcode project files
], function() {
    AdMob(requirements.xcode, requirements.fs, requirements.ncp, requirements.path);
});


function forceRequire(req, moduleNames, callback) {
  for (var i in moduleNames) {
    try {
      req[moduleNames[i]] = require(moduleNames[i]);
    }
    catch (ex) {
      downloadModule(req, moduleNames[i], function(){
        forceRequire(req, moduleNames, callback);
      });
      return;
    }
  }
  callback(req);
}

function downloadModule(req, moduleName, callback) {
  var child = exec(
    'npm install ' + moduleName + ' --silent',
    function (error, stdout, stderr) {
      if(shouldLog){
        console.log('stdout: ' + stdout);
        console.log('stderr: ' + stderr);
      }
      if (error !== null) {
        if(shouldLog){
          console.log('exec error: ' + error);
        }
      } else {
          callback();
      }
    }
  );
}



function AdMob(xcode, fs, path) {
    //parse provided config file
    var configContent = fs.readFileSync(process.argv[2], 'utf8');
    var config = JSON.parse(configContent);

    //create your variables
    var projectPath = config.project;


    //parse your project file
    var myProj = xcode.project(projectPath);
    myProj = myProj.parseSync();

    //modify contents after parseing
    myProj.addHeaderFile("AdMob/GADAdMobExtras.h");
    myProj.addHeaderFile("AdMob/GADAdNetworkExtras.h");
    myProj.addHeaderFile("AdMob/GADAdSize.h");
    myProj.addHeaderFile("AdMob/GADBannerView.h");
    myProj.addHeaderFile("AdMob/GADBannerViewDelegate.h");
    myProj.addHeaderFile("AdMob/GADInterstitial.h");
    myProj.addHeaderFile("AdMob/GADInterstitialDelegate.h");
    myProj.addHeaderFile("AdMob/GADRequest.h");
    myProj.addHeaderFile("AdMob/GADRequestError.h");
    myProj.addHeaderFile("AdMob/GADAdMobExtras.h");
    myProj.addStaticLibrary("AdMob/libGoogleAdMobAds.a", {
        plugin: true
    });
    myProj.addStaticLibrary("AdMob/libAdmobEnabled.a", {
        plugin: true
    });
    var libAdmobDisabled = myProj.removeSourceFile("libAdmobDisabled.a", {
        plugin: true
    });
    libAdmobDisabled.name = '"' + libAdmobDisabled.name + '"';

    function removeFromPbxFrameworksBuildPhase(file) {
        var sources = myProj.pbxFrameworksBuildPhaseObj();
        for (var i in sources.files) {
            if (sources.files[i].comment == longComment(file)) {
                sources.files.splice(i, 1);
                break;
            }
        }
    }


    removeFromPbxFrameworksBuildPhase(libAdmobDisabled);

    function removeFromPbxFileReferenceSection(file) {
        var i;
        var refObj = pbxFileReferenceObj(file);
        for (i in myProj.pbxFileReferenceSection()) {
            if (myProj.pbxFileReferenceSection()[i].name == refObj.name ||
                myProj.pbxFileReferenceSection()[i].path == refObj.path) {
                file.fileRef = file.uuid = i;
                delete myProj.pbxFileReferenceSection()[i];
                break;
            }
        }
        var commentKey = f("%s_comment", file.fileRef);
        if (myProj.pbxFileReferenceSection()[commentKey] != undefined) {
            delete myProj.pbxFileReferenceSection()[commentKey];
        }

        return file;
    }

    removeFromPbxFileReferenceSection(libAdmobDisabled);


    //save your modified project file
    fs.writeFileSync(projectPath, myProj.writeSync());

}

function pbxFileReferenceObj(file) {
    var obj = Object.create(null);

    obj.isa = 'PBXFileReference';
    obj.lastKnownFileType = file.lastType;

    obj.name = file.basename;
    obj.path = file.path;

    obj.sourceTree = file.sourceTree;

    if (file.fileEncoding)
        obj.fileEncoding = file.fileEncoding;

    return obj;
}

function longComment(file) {
    return f("%s in %s", file.basename, file.group);
}
